
include {sayHello} from './modules/sayHello.nf'
include {convertToUpper} from './modules/convertToUpper.nf'
include {coletaSaudacao} from './modules/coletaSaudacao.nf'
include {cowpy} from './modules/cowpy.nf'


params{
    input: Path = 'saudacao.txt'
    batch: String = 'rodada_1'
    caractere: String = 'turkey'
}

workflow{
    main:

    saudacao_ch = channel.fromPath(params.input)
                            //.view{csv -> "Antes do split: $csv"}
                            .splitCsv()
                            //.view{csv -> "Depois do split: $csv"}
                            .map{item -> item[0]}
                            //.view{csv -> "Depois do map: $csv"}
    //saudacao_vetor = ['Hello', 'Bonjour','Hola']

    //saudacao_ch = channel.of(saudacao_vetor)
    //                    .view {saudacao -> "Antes do flatten: $saudacao"}
    //                    .flatten()
    //                    .view {saudacao -> "Depois do flatten: $saudacao"}

    sayHello(saudacao_ch)
    convertToUpper(sayHello.out)
    //convertToUpper.out.view{item -> "Antes do coleta: ${item}"}
    //convertToUpper.out.collect().view{item -> "Depois do coleta: ${item}"}
    coletaSaudacao(convertToUpper.out.collect(), params.batch)
    cowpy(coletaSaudacao.out.outfile,params.caractere)

    publish:
    first_output = sayHello.out
    uppercased = convertToUpper.out
    coletaOutput = coletaSaudacao.out.outfile
    batch_report = coletaSaudacao.out.report
    desenho_out = cowpy.out
}

output {
    first_output {
        path 'hello_world'
        mode 'copy'
    }
    uppercased{
        path 'hello_world'
        mode 'copy'
    }
    coletaOutput{
        path 'hello_world'
        mode 'copy'
    }
    batch_report{
        path 'hello_world'
        mode 'copy'
    }
    desenho_out{
        path 'hello_world'
        mode 'copy'
    }

}