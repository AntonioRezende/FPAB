process convertToUpper{
    input:
    path input_file

    output:
    path "UPPER_${input_file}"

    script:
    """
    cat '${input_file}' | tr '[a-z]' '[A-Z]' > 'UPPER_${input_file}'
    """
}