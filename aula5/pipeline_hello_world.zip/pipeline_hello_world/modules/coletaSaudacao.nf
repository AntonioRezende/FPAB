process coletaSaudacao{
    input:
    path input_files
    val batch_name

    output:
    path "Coleta_${batch_name}_output.txt", emit:outfile
    path "${batch_name}_report.txt", emit:report

    script:
    """
    cat ${input_files} > 'Coleta_${batch_name}_output.txt'
    echo "Essa e a rodada ${batch_name}." > "${batch_name}_report.txt"
    """
}