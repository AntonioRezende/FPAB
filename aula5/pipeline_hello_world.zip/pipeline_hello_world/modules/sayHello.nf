process sayHello{

    input:
    val saudacao

    output:
    path "${saudacao}_output.txt"

    script:
    """
    echo '${saudacao}' > '${saudacao}_output.txt'
    """
}