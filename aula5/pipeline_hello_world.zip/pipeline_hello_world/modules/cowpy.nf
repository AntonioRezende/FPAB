process cowpy{
    container 'community.wave.seqera.io/library/cowpy:1.1.5--37c4f79705e7c4c3'

    input:
    path input_file
    val caractere

    output:
    path "cowpy_${input_file}"

    script:
    """
    cat ${input_file} | cowpy -c "${caractere}" > cowpy_${input_file}
    """
}