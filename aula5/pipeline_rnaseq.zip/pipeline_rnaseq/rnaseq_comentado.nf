#!/usr/bin/env nextflow

// Module INCLUDE statements
include {fastqc} from './modules/fastqc.nf'
include {build} from './modules/build.nf'
include {multiqc} from './modules/multiqc.nf'
include {trim} from './modules/trim.nf'
include {align} from './modules/align.nf'
/*
 * Pipeline parameters
 */

// Primary input
params{
    input: Path = 'input.txt'
    referencia: Path = 'referencia.fa'
}


workflow {

    main:
    // Create input channel
    input_ch = channel.fromPath(params.input)
                            //.view()
                            .splitCsv(header: true)
                            //.view()
                            //.map{teste -> teste.sample_id}
                            //.map{row -> tuple(row.sample_id,file(row.fastq_1), file(row.fastq_2))}
                            //.view()
    referencia_ch = channel.fromPath(params.referencia)

    // Call processes
    fastqc(input_ch)
    trim(input_ch)

    //Concatenando canais de saido do fastqc e trim
    
    build(referencia_ch)
    
    //build.out.view()
    //trim.out.trimmed_reads.view()
    //trim.out.trimmed_reads.combine(build.out).view()
    
    align(trim.out.trimmed_reads.combine(build.out))

    //align(trim.out.trimmed_reads,build.out)

    //checkIndex=build.out.map{item -> item[0].simpleName}
    //checkIndex.map{item -> item[0].simpleName}
    //.view()

    //hisatindex = checkIndex.combine(build.out).map{name,files->tuple(name)}
    //hisatindex.view()

    //align(trim.out.trimmed_reads,build.out,build.out.map{item->item[0]})
    //align(trim.out.trimmed_reads,hisatindex)


    //Concatenando canais de saido do fastqc, trim e hisat2-align
    trim_fastqc_align_ch = fastqc.out.zipfile.collect().mix(trim.out.fastqc_reports_1.collect()).mix(trim.out.fastqc_reports_2.collect()).mix(align.out.log.collect())//.view()
    //trim_fastqc_aling_ch//.collect()//.view()

    multiqc(trim_fastqc_align_ch.collect())


    publish:
    // Declare outputs to publish
    fastqczip = fastqc.out.zipfile
    fastqchtml = fastqc.out.htmlfile
    refindex = build.out
    multiqcout = multiqc.out.htmlreport
    multiqcdata = multiqc.out.multiqcdata
    trimmed_reads = trim.out.trimmed_reads
    trimming_reports = trim.out.trimming_reports
    fastqc_trim_report1 = trim.out.fastqc_reports_1
    fastqc_trim_report2 = trim.out.fastqc_reports_2
    alignlog = align.out.log
    mapping = align.out.samfile
}

output {
    // Configure publish targets
    fastqczip{
        path 'fastqc'
        mode 'copy'
    }
    fastqchtml{
        path 'fastqc'
        mode 'copy'
    }
    refindex{
        path 'index'
        mode 'copy'
    }
    multiqcout{
        path 'multiqc'
        mode 'copy'
    }
    multiqcdata{
        path 'multiqc'
        mode 'copy'
    }
    trimmed_reads{
        path 'trim'
        mode 'copy'
    }
    trimming_reports{
        path 'trim'
        mode 'copy'
    }
    fastqc_trim_report1{
        path 'trim'
        mode 'copy'
    }
    fastqc_trim_report2{
        path 'trim'
        mode 'copy'
    }
    alignlog{
        path 'align'
        mode 'copy'
    }
    mapping{
        path 'align'
        mode 'copy'
    }
}
