#!/usr/bin/env nextflow

// Module INCLUDE statements
include {fastqc} from './modules/fastqc.nf'
include {build} from './modules/build.nf'
include {multiqc} from './modules/multiqc.nf'
include {trim} from './modules/trim.nf'
include {align} from './modules/align.nf'
/*
 * Pipeline parameters
 */

// Primary input
params{
    input: Path = 'input.txt'
    referencia: Path = 'referencia.fa'
}


workflow {

    main:
    // Create input channel
    input_ch = channel.fromPath(params.input)
                            .splitCsv(header: true)
                            
    referencia_ch = channel.fromPath(params.referencia)

    // Call processes
    fastqc(input_ch)
    trim(input_ch)

    build(referencia_ch)
    align(trim.out.trimmed_reads.combine(build.out))

    //Concatenando canais de saido do fastqc, trim e hisat2-align
    //trim_fastqc_align_ch = fastqc.out.zipfile.collect().mix(trim.out.fastqc_reports_1.collect()).mix(trim.out.fastqc_reports_2.collect()).mix(align.out.log.collect())//.view()
    trim_fastqc_align_ch = fastqc.out.zipfile.mix(trim.out.fastqc_reports_1).mix(trim.out.fastqc_reports_2).mix(align.out.log)//.view()
    
    multiqc(trim_fastqc_align_ch.collect())


    publish:
    // Declare outputs to publish
    fastqczip = fastqc.out.zipfile
    fastqchtml = fastqc.out.htmlfile
    refindex = build.out
    multiqcout = multiqc.out.htmlreport
    multiqcdata = multiqc.out.multiqcdata
    trimmed_reads = trim.out.trimmed_reads
    trimming_reports = trim.out.trimming_reports
    fastqc_trim_report1 = trim.out.fastqc_reports_1
    fastqc_trim_report2 = trim.out.fastqc_reports_2
    alignlog = align.out.log
    mapping = align.out.samfile
}

output {
    // Configure publish targets
    fastqczip{
        path 'fastqc'
        mode 'copy'
    }
    fastqchtml{
        path 'fastqc'
        mode 'copy'
    }
    refindex{
        path 'index'
        mode 'copy'
    }
    multiqcout{
        path 'multiqc'
        mode 'copy'
    }
    multiqcdata{
        path 'multiqc'
        mode 'copy'
    }
    trimmed_reads{
        path 'trim'
        mode 'copy'
    }
    trimming_reports{
        path 'trim'
        mode 'copy'
    }
    fastqc_trim_report1{
        path 'trim'
        mode 'copy'
    }
    fastqc_trim_report2{
        path 'trim'
        mode 'copy'
    }
    alignlog{
        path 'align'
        mode 'copy'
    }
    mapping{
        path 'align'
        mode 'copy'
    }
}
