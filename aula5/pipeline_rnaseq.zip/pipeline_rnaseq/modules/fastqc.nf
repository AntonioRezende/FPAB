process fastqc{
   container 'community.wave.seqera.io/library/fastqc_hisat2_multiqc_trim-galore:03f9d3d14cb4371d'

    input:
    tuple val(sample_id), path(seq1), path(seq2)

    output:
    path "${sample_id}*.zip", emit:zipfile
    path "${sample_id}*.html", emit:htmlfile

    script:
    """
    fastqc ${seq1} ${seq2}
    """
    
}