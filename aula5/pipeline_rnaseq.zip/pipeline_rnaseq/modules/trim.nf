process trim{
   container 'community.wave.seqera.io/library/fastqc_hisat2_multiqc_trim-galore:03f9d3d14cb4371d'

    input:
    tuple val(sample_id), path(seq1), path(seq2)

    output:
    tuple val(sample_id), path("*_val_1.fq.gz"), path("*_val_2.fq.gz"), emit: trimmed_reads
    path "*_trimming_report.txt", emit: trimming_reports
    path "*_val_1_fastqc.{zip,html}", emit: fastqc_reports_1
    path "*_val_2_fastqc.{zip,html}", emit: fastqc_reports_2

    script:
    """
    trim_galore -q 40 --illumina --length 50 --fastqc --paired ${seq1} ${seq2}
    """
    
}