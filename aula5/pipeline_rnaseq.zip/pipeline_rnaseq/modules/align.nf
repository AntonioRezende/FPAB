process align{
   container 'community.wave.seqera.io/library/fastqc_hisat2_multiqc_trim-galore:03f9d3d14cb4371d'

    input:
    tuple val(sample), path(seq1), path(seq2), val(index), path (indexfiles)
    //tuple val(index), path (indexfiles)

    output:
    //path "${seq1.simpleName}.hisat2.log", emit: log
    path "${sample}.hisat2.log", emit: log
    path "${sample}.hisat2.sam", emit: samfile
    
    script:
    """
    hisat2 -x ${index} -1 ${seq1} -2 ${seq2} \
        --new-summary --summary-file ${sample}.hisat2.log > ${sample}.hisat2.sam
    """
    
}