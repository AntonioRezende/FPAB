process multiqc{
   container 'community.wave.seqera.io/library/fastqc_hisat2_multiqc_trim-galore:03f9d3d14cb4371d'

    input:
    path input_files

    output:
    path "multiqc_report.html", emit:htmlreport
    path "multiqc_data", emit:multiqcdata

    script:
    """
    multiqc .
    """
    
}