process build{
   container 'community.wave.seqera.io/library/fastqc_hisat2_multiqc_trim-galore:03f9d3d14cb4371d'

    input:
    path ref

    output:
    tuple val("genome_index"), path("genome_index.*")

    script:
    """
    hisat2-build ${ref} genome_index
    """
    
}